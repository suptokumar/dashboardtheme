
<?php $__env->startSection("title","Admin Portal"); ?>
<?php $__env->startSection("active","withdrawal"); ?>
<?php $__env->startSection("content"); ?>
<article>
<header style="overflow: hidden;">

    <a href="<?php echo e(url('/admin/withdrawal')); ?>" class="btn btn-info float-left">Withdrawal List</a>

</header>
<section class="gateway_view">
  <form action="<?php echo e(url('/admin/createapi/declinewithdrawal')); ?>" method="POST" enctype="multipart/form-data">
<br>
<?php if($message = session("message")): ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if($success = session("success")): ?>
<div class="alert alert-success" role="alert">
<?php echo e($success); ?>

</div>
<?php endif; ?>


<input type="hidden" name="id" value="<?php echo e($withdrawal->id); ?>">
    <?php echo csrf_field(); ?>
<div class="alert alert-info">
  <?php if($withdrawal->status=='declined'): ?>
    Deposit successfuly declined. 
  <?php else: ?>
	You are going to <b>Decline</b> a withdraw request. Please make sure the detail before you decline it.
  <?php endif; ?>
</div>
  <div class="form-row">

    <div class="form-group col-md-6">
    	<div style="padding: 20px">
    	<h6>Amount: <?php echo e($withdrawal->amount); ?></h6>
    	<h6>Currency: <?php echo e($withdrawal->currency); ?></h6>
    	<h6>Deposit ID: <?php echo e($withdrawal->idm); ?></h6>
    	<h6>Gateway: <?php echo e($withdrawal->gateway); ?></h6>
      <h6>Gateway Info:<br><pre style="color: white">
<?php echo e($withdrawal->info); ?></pre></h6>
    	</div>
    </div>
  <?php if($withdrawal->status!='declined'): ?>

    <div class="form-group col-md-6">
      <label for="declinecause">Write the cause why are you declining the request <span class="red">*</span></label>
      <textarea  class="form-control" name="declinecause" required="" id="declinecause" placeholder="eg: The amount hasn't been transfered  yet."></textarea> 
  <div style="text-align: center;">
  <button type="submit" class="btn btn-primary">Decline Now</button>
  </div>
    </div>
  <?php endif; ?>

  </div>

  <br>
</form>
</section>
</article>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<style>
.page-content .grid > article:first-child {
    grid-column: 1 / -1;
    display: block;
}
.multiselect-native-select {
    width: 100%;
    display: block;
}
.form-check-label{
  color: black;
}
.btn-group, .btn-group-vertical{
  display: block !important;
}
.multiselect-container{
  width: 100%;
}
.custom-select{
  background: #242222 url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='4' height='5' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3e%3c/svg%3e") no-repeat right .75rem center/8px 10px;
  color: #90979d;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lvapi\resources\views/withdrawal/declinewithdrawal.blade.php ENDPATH**/ ?>