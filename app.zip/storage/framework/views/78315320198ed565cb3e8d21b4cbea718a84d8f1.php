
<?php $__env->startSection("title","Admin Portal"); ?>
<?php $__env->startSection("active","deposit"); ?>
<?php $__env->startSection("content"); ?>
<article>
<header style="overflow: hidden;">

    <a href="<?php echo e(url('/admin/deposit')); ?>" class="btn btn-info float-left">Deposit List</a>

</header>
<section class="gateway_view">
<br>
<?php if($message = session("message")): ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if($success = session("success")): ?>
<div class="alert alert-success" role="alert">
<?php echo e($success); ?>

</div>
<?php endif; ?>

<?php
	use App\Http\Controllers\soft;
?>
<input type="hidden" name="id" value="<?php echo e($deposit->id); ?>">
    <?php echo csrf_field(); ?>
  <div class="form-row">

    <div class="form-group col-md-6">
    	<a href="<?php echo e(url('/public/'.$deposit->screenshot)); ?>" target="_blank"><img src="<?php echo e(url('/public/'.$deposit->screenshot)); ?>" style="height: 200px" alt=""></a>
    	<div style="padding: 20px">
    	<h6>Amount: <?php echo e($deposit->amount); ?></h6>
    	<h6>Currency: <?php echo e($deposit->currency); ?></h6>
    	<h6>Gateway: <?php echo e($deposit->gateway); ?></h6>
    	<h6>Deposit ID: <?php echo e($deposit->idm); ?></h6>
    	<h6>Status: <?php echo e($deposit->status); ?></h6>
<?php if($deposit->status!='approved'): ?>
    	<button onclick='edit(<?php echo e($deposit->id); ?>)' class="btn btn-success">Approve</button>
<?php endif; ?>
<?php if($deposit->status!='declined'): ?>
    	<button onclick='decline(<?php echo e($deposit->id); ?>)' class="btn btn-warning">Decline</button>
<?php endif; ?>
    	<button onclick='deletes(<?php echo e($deposit->id); ?>)' class="btn btn-danger">Delete</button>
    	</div>
    </div>

    <div class="form-group col-md-6">
<div>
<img src="<?php echo e(url('/public/'.$user->image)); ?>" alt="profile" style="width: 100px; height: 100px; border-radius: 100px">
</div>
<h4><a href="<?php echo e(url('/user/'.$user->phone)); ?>"><?php echo e($user->name); ?></a></h4>
<h5>Contact: <?php echo e($user->phone); ?></h5>
<h5>Email: <?php echo e($user->email); ?></h5>
<h5>Member Since: <?php echo e(date("d M Y",strtotime($user->created_at))); ?></h5>
<h5>Wallet Balance: ₹<?php echo e(soft::wallet($user->phone)); ?></h5>
<h5>Available IDs: <?php echo e(count($idm)); ?></h5>
<?php if(count($idm)): ?>
<table class="table" style="color: white;">
<tr>
<th> ID </th>
<th>Balance</th>
</tr>
<?php $__currentLoopData = $idm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
<td><?php echo e($ids->name); ?></td>
<td><?php echo e($ids->balance); ?></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
    </div>

  </div>

  <br>

</section>
</article>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>
<style>
.page-content .grid > article:first-child {
    grid-column: 1 / -1;
    display: block;
}
.multiselect-native-select {
    width: 100%;
    display: block;
}
.form-check-label{
  color: black;
}
.btn-group, .btn-group-vertical{
  display: block !important;
}
.multiselect-container{
  width: 100%;
}
.custom-select{
  background: #242222 url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='4' height='5' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3e%3c/svg%3e") no-repeat right .75rem center/8px 10px;
  color: #90979d;
}
</style>
<script>

function edit(id)
  {
   if (confirm("Are you sure you want to approve the deposit?")) {
    $.ajax({
      url: '<?php echo e(url('/admin/approvedepositid')); ?>',
      type: 'POST',
      data: {id: id,_token:"<?php echo e(csrf_token()); ?>"},
    })
    .done(function(data) {
      $(".acd"+id).fadeOut('slow');
    });
  }
  }


  function decline(id)
  {
   window.location = '<?php echo e(url('/admin/declinedepositid/')); ?>/'+id;
  }
  function details(id)
  {
   window.location = '<?php echo e(url('/admin/depositid/')); ?>/'+id;
  }
  function manageroll(id)
  {
    window.location = '<?php echo e(url('/admin/privileges/')); ?>/'+id;
  }
function fc_this(th,id){
		$.ajax({
			url: '<?php echo e(url('/admin/statuschanger')); ?>',
			type: 'POST',
			data: {id: id,_token:"<?php echo e(csrf_token()); ?>"},
		})
		.done(function(data) {
		});
}
function deletes(id){
  if (confirm("Are you sure you want to delete the deposit?\nIf you delete it, it will be removed with the amount.")) {
    $.ajax({
      url: '<?php echo e(url('/admin/deletedepositid')); ?>',
      type: 'POST',
      data: {id: id,_token:"<?php echo e(csrf_token()); ?>"},
    })
    .done(function(data) {
      $(".acd"+id).fadeOut('slow');
    });
  }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lvapi\resources\views/iddeposit/iddepositview.blade.php ENDPATH**/ ?>